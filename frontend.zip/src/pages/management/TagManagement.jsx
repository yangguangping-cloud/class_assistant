import { useState, useEffect } from 'react'
import { Table, Button, Modal, Form, Input, message, Popconfirm } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
import { tagsAPI } from '../../services/api'

function TagManagement() {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalVisible, setModalVisible] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [form] = Form.useForm()

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await tagsAPI.list()
      setData(res.data)
    } catch (err) {
      message.error('获取数据失败')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = async () => {
    const values = await form.validateFields()
    try {
      if (editingItem) {
        await tagsAPI.update(editingItem.id, values)
      } else {
        await tagsAPI.create(values)
      }
      message.success('操作成功')
      setModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('操作失败')
    }
  }

  const handleDelete = async (id) => {
    try {
      await tagsAPI.delete(id)
      message.success('删除成功')
      fetchData()
    } catch (err) {
      message.error('删除失败')
    }
  }

  const columns = [
    { title: 'ID', dataIndex: 'id', key: 'id' },
    { title: '标签名称', dataIndex: 'name', key: 'name' },
    {
      title: '操作', key: 'action', render: (_, record) => (
        <>
          <Button icon={<EditOutlined />} onClick={() => { setEditingItem(record); form.setFieldsValue(record); setModalVisible(true) }} />
          <Popconfirm title="确定删除?" onConfirm={() => handleDelete(record.id)}>
            <Button icon={<DeleteOutlined />} danger style={{ marginLeft: 8 }} />
          </Popconfirm>
        </>
      )
    }
  ]

  return (
    <div>
      <Button type="primary" icon={<PlusOutlined />} onClick={() => { setEditingItem(null); form.resetFields(); setModalVisible(true) }}>
        新增标签
      </Button>
      <Table columns={columns} dataSource={data} rowKey="id" loading={loading} style={{ marginTop: 16 }} />
      <Modal title={editingItem ? '编辑标签' : '新增标签'} open={modalVisible} onOk={handleSubmit} onCancel={() => setModalVisible(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="标签名称" rules={[{ required: true }]}><Input /></Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default TagManagement
