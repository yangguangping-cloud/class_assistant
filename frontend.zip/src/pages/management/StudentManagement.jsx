import { useState, useEffect } from 'react'
import { Table, Button, Modal, Form, Input, Select, message, Popconfirm, Upload, Space, Tag } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined, UploadOutlined, ArrowUpOutlined, DownloadOutlined } from '@ant-design/icons'
import { studentsAPI, classesAPI } from '../../services/api'
import * as XLSX from 'xlsx'

function StudentManagement() {
  const [data, setData] = useState([])
  const [classes, setClasses] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalVisible, setModalVisible] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [form] = Form.useForm()
  const [importModalVisible, setImportModalVisible] = useState(false)
  const [activeFilter, setActiveFilter] = useState(true) // 默认显示有效学生

  const fetchData = async (active = activeFilter) => {
    setLoading(true)
    try {
      const [studentsRes, classesRes] = await Promise.all([
        studentsAPI.list({ params: { active } }),
        classesAPI.list()
      ])
      setData(studentsRes.data)
      setClasses(classesRes.data)
    } catch (err) {
      message.error('获取数据失败')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = async () => {
    const values = await form.validateFields()
    try {
      if (editingItem) {
        await studentsAPI.update(editingItem.id, values)
      } else {
        await studentsAPI.create(values)
      }
      message.success('操作成功')
      setModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('操作失败')
    }
  }

  const handleDelete = async (id) => {
    try {
      await studentsAPI.delete(id)
      message.success('删除成功')
      fetchData()
    } catch (err) {
      message.error('删除失败')
    }
  }

  const getClassName = (id) => classes.find(c => c.id === id)?.display_name || '-'
  const formatBirthday = (date) => date ? new Date(date).toISOString().split('T')[0] : '-'
  const renderActive = (active) => active ? <Tag color="green">有效</Tag> : <Tag color="red">无效</Tag>

  const columns = [
    { title: 'ID', dataIndex: 'id', key: 'id' },
    { title: '姓名', dataIndex: 'name', key: 'name' },
    { title: '性别', dataIndex: 'gender', key: 'gender' },
    { title: '生日', dataIndex: 'birthday', key: 'birthday', render: formatBirthday },
    { title: '年龄', dataIndex: 'age', key: 'age' },
    { title: '身高(cm)', dataIndex: 'height', key: 'height' },
    { title: '体重(kg)', dataIndex: 'weight', key: 'weight' },
    { title: '班级', dataIndex: 'class_id', key: 'class_id', render: getClassName },
    { title: '状态', dataIndex: 'active', key: 'active', render: renderActive },
    { title: '爱好', dataIndex: 'hobbies', key: 'hobbies' },
    {
      title: '操作', key: 'action', render: (_, record) => (
        <>
          <Button icon={<EditOutlined />} onClick={() => { setEditingItem(record); form.setFieldsValue(record); setModalVisible(true) }} />
          <Popconfirm title="确定删除?" onConfirm={() => handleDelete(record.id)}>
            <Button icon={<DeleteOutlined />} danger style={{ marginLeft: 8 }} />
          </Popconfirm>
        </>
      )
    }
  ]

  const handleImport = async (file) => {
    try {
      const formData = new FormData()
      formData.append('file', file)
      await studentsAPI.import(formData)
      message.success('导入成功')
      setImportModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('导入失败')
    }
    return false
  }

  const downloadSampleFile = () => {
    const headers = ['姓名', '性别', '班级', '生日', '身高(cm)', '体重(kg)', '爱好', '朋友']
    const sampleData = [
      ['张三', '男', '一年级一班', '2015-05-10', 120, 25, '篮球,游泳', '李四,王五'],
      ['李四', '女', '一年级一班', '2015-08-20', 118, 23, '绘画,音乐', '张三,赵六']
    ]
    
    const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData])
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, '学生导入示例')
    XLSX.writeFile(wb, '学生导入示例.xlsx')
  }

  const handlePromote = async () => {
    try {
      await studentsAPI.promote()
      message.success('升级成功')
      fetchData()
    } catch (err) {
      message.error('升级失败')
    }
  }

  return (
    <div>
      <Space style={{ marginBottom: 16 }}>
        <Button type="primary" icon={<PlusOutlined />} onClick={() => { setEditingItem(null); form.resetFields(); setModalVisible(true) }}>
          新增学生
        </Button>
        <Button icon={<UploadOutlined />} onClick={() => setImportModalVisible(true)}>
          导入学生
        </Button>
        <Popconfirm title="确定将所有学生升级到下一个年级？（六年级学生将标记为无效）" onConfirm={handlePromote}>
          <Button icon={<ArrowUpOutlined />}>
            年级升级
          </Button>
        </Popconfirm>
        <Select
          value={activeFilter}
          onChange={(value) => { setActiveFilter(value); fetchData(value) }}
          style={{ width: 120 }}
          options={[
            { label: '显示有效', value: true },
            { label: '显示无效', value: false },
            { label: '显示全部', value: null }
          ]}
        />
      </Space>
      <Table columns={columns} dataSource={data} rowKey="id" loading={loading} style={{ marginTop: 16 }} />
      <Modal title={editingItem ? '编辑学生' : '新增学生'} open={modalVisible} onOk={handleSubmit} onCancel={() => setModalVisible(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="姓名" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="gender" label="性别" rules={[{ required: true }]}>
            <Select options={[{ label: '男', value: '男' }, { label: '女', value: '女' }]} />
          </Form.Item>
          <Form.Item name="birthday" label="生日">
            <Input type="date" />
          </Form.Item>
          <Form.Item name="height" label="身高(cm)"><Input type="number" /></Form.Item>
          <Form.Item name="weight" label="体重(kg)"><Input type="number" /></Form.Item>
          <Form.Item name="hobbies" label="爱好"><Input.TextArea /></Form.Item>
          <Form.Item name="friends" label="好友"><Input.TextArea /></Form.Item>
          <Form.Item name="class_id" label="班级" rules={[{ required: true }]}>
            <Select options={classes.map(c => ({ label: c.display_name, value: c.id }))} />
          </Form.Item>
        </Form>
      </Modal>
      <Modal title="导入学生" open={importModalVisible} onCancel={() => setImportModalVisible(false)} footer={null}>
        <div style={{ marginBottom: 16 }}>
          <Button 
            type="link" 
            icon={<DownloadOutlined />} 
            onClick={downloadSampleFile}
            style={{ padding: 0 }}
          >
            下载导入示例文件
          </Button>
        </div>
        <Upload.Dragger
          name="file"
          accept=".xlsx,.xls"
          beforeUpload={handleImport}
          showUploadList={false}
        >
          <p className="ant-upload-drag-icon">
            <UploadOutlined />
          </p>
          <p className="ant-upload-text">点击或拖拽Excel文件到此区域</p>
          <p className="ant-upload-hint">
            支持 .xlsx, .xls 格式<br/>
            必填字段：姓名, 性别, 班级<br/>
            可选字段：生日, 身高(cm), 体重(kg), 爱好, 朋友
          </p>
        </Upload.Dragger>
      </Modal>
    </div>
  )
}

export default StudentManagement
