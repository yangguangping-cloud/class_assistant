import { useState, useEffect } from 'react'
import { Table, Button, Modal, Form, Input, Select, message, Popconfirm, Upload, Space } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined, UploadOutlined, DownloadOutlined } from '@ant-design/icons'
import { scoresAPI, studentsAPI, classesAPI, subjectsAPI } from '../../services/api'
import dayjs from 'dayjs'
import * as XLSX from 'xlsx'

const scoreTypes = ['月考', '期中考试', '期末考试', '随堂测验']

function ScoreManagement() {
  const [data, setData] = useState([])
  const [students, setStudents] = useState([])
  const [classes, setClasses] = useState([])
  const [subjects, setSubjects] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalVisible, setModalVisible] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [form] = Form.useForm()
  const [importModalVisible, setImportModalVisible] = useState(false)

  const fetchData = async () => {
    setLoading(true)
    try {
      const [scoresRes, studentsRes, classesRes, subjectsRes] = await Promise.all([
        scoresAPI.list(), studentsAPI.list(), classesAPI.list(), subjectsAPI.list()
      ])
      setData(scoresRes.data)
      setStudents(studentsRes.data)
      setClasses(classesRes.data)
      setSubjects(subjectsRes.data)
    } catch (err) {
      message.error('获取数据失败')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = async () => {
    const values = await form.validateFields()
    try {
      if (editingItem) {
        await scoresAPI.update(editingItem.id, values)
      } else {
        await scoresAPI.create(values)
      }
      message.success('操作成功')
      setModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('操作失败')
    }
  }

  const handleImport = async (file) => {
    try {
      await scoresAPI.import(file)
      message.success('导入成功')
      setImportModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('导入失败')
    }
    return false
  }

  const downloadSampleFile = () => {
    const headers = ['姓名', '班级', '学科', '考试类型', '成绩', '考试日期']
    const sampleData = [
      ['张三', '一年级一班', '语文', '月考', 95, '2025-03-15'],
      ['李四', '一年级一班', '数学', '期中考试', 88, '2025-04-20']
    ]
    
    const ws = XLSX.utils.aoa_to_sheet([headers, ...sampleData])
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, '成绩导入示例')
    XLSX.writeFile(wb, '成绩导入示例.xlsx')
  }

  const handleDelete = async (id) => {
    try {
      await scoresAPI.delete(id)
      message.success('删除成功')
      fetchData()
    } catch (err) {
      message.error('删除失败')
    }
  }

  const getStudentName = (id) => students.find(s => s.id === id)?.name || '-'
  const getClassName = (id) => classes.find(c => c.id === id)?.display_name || '-'
  const getSubjectName = (id) => subjects.find(s => s.id === id)?.name || '-'

  const columns = [
    { title: 'ID', dataIndex: 'id', key: 'id' },
    { title: '学生', dataIndex: 'student_id', key: 'student_id', render: getStudentName },
    { title: '班级', dataIndex: 'class_id', key: 'class_id', render: getClassName },
    { title: '学科', dataIndex: 'subject_id', key: 'subject_id', render: getSubjectName },
    { title: '考试类型', dataIndex: 'score_type', key: 'score_type' },
    { title: '成绩', dataIndex: 'score', key: 'score' },
    { title: '考试日期', dataIndex: 'exam_date', key: 'exam_date' },
    {
      title: '操作', key: 'action', render: (_, record) => (
        <>
          <Button icon={<EditOutlined />} onClick={() => { setEditingItem(record); form.setFieldsValue(record); setModalVisible(true) }} />
          <Popconfirm title="确定删除?" onConfirm={() => handleDelete(record.id)}>
            <Button icon={<DeleteOutlined />} danger style={{ marginLeft: 8 }} />
          </Popconfirm>
        </>
      )
    }
  ]

  return (
    <div>
      <Space style={{ marginBottom: 16 }}>
        <Button type="primary" icon={<PlusOutlined />} onClick={() => { setEditingItem(null); form.resetFields(); setModalVisible(true) }}>
          新增成绩
        </Button>
        <Button icon={<UploadOutlined />} onClick={() => setImportModalVisible(true)}>
          导入成绩
        </Button>
      </Space>
      <Table columns={columns} dataSource={data} rowKey="id" loading={loading} style={{ marginTop: 16 }} />
      <Modal title={editingItem ? '编辑成绩' : '新增成绩'} open={modalVisible} onOk={handleSubmit} onCancel={() => setModalVisible(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="student_id" label="学生" rules={[{ required: true }]}>
            <Select options={students.map(s => ({ label: s.name, value: s.id }))} />
          </Form.Item>
          <Form.Item name="class_id" label="班级" rules={[{ required: true }]}>
            <Select options={classes.map(c => ({ label: c.display_name, value: c.id }))} />
          </Form.Item>
          <Form.Item name="subject_id" label="学科" rules={[{ required: true }]}>
            <Select options={subjects.map(s => ({ label: s.name, value: s.id }))} />
          </Form.Item>
          <Form.Item name="score_type" label="考试类型" rules={[{ required: true }]}>
            <Select options={scoreTypes.map(t => ({ label: t, value: t }))} />
          </Form.Item>
          <Form.Item name="score" label="成绩" rules={[{ required: true }]}>
            <Input type="number" />
          </Form.Item>
          <Form.Item name="exam_date" label="考试日期" rules={[{ required: true }]}>
            <Input type="date" />
          </Form.Item>
        </Form>
      </Modal>
      <Modal title="导入成绩" open={importModalVisible} onCancel={() => setImportModalVisible(false)} footer={null}>
        <div style={{ marginBottom: 16 }}>
          <Button 
            type="link" 
            icon={<DownloadOutlined />} 
            onClick={downloadSampleFile}
            style={{ padding: 0 }}
          >
            下载导入示例文件
          </Button>
        </div>
        <Upload.Dragger
          name="file"
          accept=".xlsx,.xls"
          beforeUpload={handleImport}
          showUploadList={false}
        >
          <p className="ant-upload-drag-icon">
            <UploadOutlined />
          </p>
          <p className="ant-upload-text">点击或拖拽Excel文件到此区域</p>
          <p className="ant-upload-hint">
            支持 .xlsx, .xls 格式<br/>
            必填字段：姓名, 班级, 学科, 考试类型, 成绩, 考试日期
          </p>
        </Upload.Dragger>
      </Modal>
    </div>
  )
}

export default ScoreManagement
