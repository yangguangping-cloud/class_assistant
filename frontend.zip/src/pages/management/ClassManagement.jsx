import { useState, useEffect } from 'react'
import { Table, Button, Modal, Form, Input, Select, message, Popconfirm } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
import { classesAPI, gradesAPI, usersAPI } from '../../services/api'

function ClassManagement() {
  const [data, setData] = useState([])
  const [grades, setGrades] = useState([])
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalVisible, setModalVisible] = useState(false)
  const [editingItem, setEditingItem] = useState(null)
  const [form] = Form.useForm()

  const fetchData = async () => {
    setLoading(true)
    try {
      const [classesRes, gradesRes, usersRes] = await Promise.all([
        classesAPI.list(), gradesAPI.list(), usersAPI.list()
      ])
      setData(classesRes.data)
      setGrades(gradesRes.data)
      setUsers(usersRes.data)
    } catch (err) {
      message.error('获取数据失败')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = async () => {
    const values = await form.validateFields()
    try {
      if (editingItem) {
        await classesAPI.update(editingItem.id, values)
        message.success('更新成功')
      } else {
        await classesAPI.create(values)
        message.success('创建成功')
      }
      setModalVisible(false)
      fetchData()
    } catch (err) {
      message.error('操作失败')
    }
  }

  const handleDelete = async (id) => {
    try {
      await classesAPI.delete(id)
      message.success('删除成功')
      fetchData()
    } catch (err) {
      message.error('删除失败')
    }
  }

  const getGradeName = (id) => grades.find(g => g.id === id)?.name || '-'
  const getTeacherName = (id) => users.find(u => u.id === id)?.name || '-'

  const columns = [
    { title: 'ID', dataIndex: 'id', key: 'id' },
    { title: '班级名称', dataIndex: 'display_name', key: 'display_name' },
    { title: '年级', dataIndex: 'grade_id', key: 'grade_id', render: getGradeName },
    { title: '任课老师', dataIndex: 'teacher_id', key: 'teacher_id', render: getTeacherName },
    {
      title: '操作',
      key: 'action',
      render: (_, record) => (
        <>
          <Button icon={<EditOutlined />} onClick={() => { setEditingItem(record); form.setFieldsValue(record); setModalVisible(true) }} />
          <Popconfirm title="确定删除?" onConfirm={() => handleDelete(record.id)}>
            <Button icon={<DeleteOutlined />} danger style={{ marginLeft: 8 }} />
          </Popconfirm>
        </>
      )
    }
  ]

  return (
    <div>
      <Button type="primary" icon={<PlusOutlined />} onClick={() => { setEditingItem(null); form.resetFields(); setModalVisible(true) }}>
        新增班级
      </Button>
      <Table columns={columns} dataSource={data} rowKey="id" loading={loading} style={{ marginTop: 16 }} />
      <Modal title={editingItem ? '编辑班级' : '新增班级'} open={modalVisible} onOk={handleSubmit} onCancel={() => setModalVisible(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="班级名称" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="grade_id" label="年级" rules={[{ required: true }]}>
            <Select options={grades.map(g => ({ label: g.name, value: g.id }))} />
          </Form.Item>
          <Form.Item name="teacher_id" label="任课老师" rules={[{ required: true }]}>
            <Select options={users.map(u => ({ label: u.name, value: u.id }))} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default ClassManagement
